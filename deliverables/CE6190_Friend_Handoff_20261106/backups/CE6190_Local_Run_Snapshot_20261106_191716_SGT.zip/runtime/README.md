# A100 handoff run — 2026-11-06

Authorized scope: deduplicated union of the handoff's pending H200/L40S tasks,
reported as a separate A100-PCIE-40GB group; never fill original hardware timings.
1473 pending cached tasks + 119 same-environment Uncached references = 1592 tasks.
Original handoff files and profiles are unchanged. `plan.json` records path mapping.
No DrawBench, VBench scoring, extra calibration, or component ablations.

Physical GPUs 0/1/2 are pinned by UUID. Physical GPU 3 is forbidden.
From 2026-11-06 12:45:50 +08:00, only GPUs 0/1 may receive new tasks.
A task already running on GPU 2 may finish; it will not be replaced.
The five-method smoke uses the original 81 frames / 50 steps / warmup 1 / repeats 3.
Batch admission occurs only after all five complete with validated artifacts.
Any failure stops new admissions; other in-flight tasks finish normally.

Service: `ce6190-a100-20261106.service` (user systemd, survives terminal closure).
Status: `status.json`. Logs: `logs/<run_id>.log`, `controller.log`.
Outputs: `results/<run_id>/{metrics.json,trace.json,frames.npy,video.mp4}`.
Full environment freeze and preflight verification evidence are retained here.

To drain without interrupting samples: create `STOP` in this directory.
No automatic restart after host reboot is promised. On manual restart, complete
matching artifacts are skipped; incomplete or failed directories require explicit
inspection and retry, never silent overwrite. There is no mid-video recovery.

Known limitation: full original runtime project snapshot was not supplied. Known
calibration/start-script hashes and core official denoising hashes match original
records; all pinned key library versions match. Python is 3.11.18 vs 3.11.9.

## 2026-11-06 friend transfer

Original full manifest/plan preserved as *.before-friend-split.*.
Local queue now 230 total (183 completed at handoff, 47 remaining).
1362 other tasks are exclusively assigned to the friend handoff package.
No generated output was altered or deleted. Two GPUs remain permitted.
Target finish: 2026-11-07 03:00 SGT; a user systemd timer stops new admissions
at 02:30 SGT, allowing in-flight tasks to complete. Any unexpected leftovers
remain locally owned until a separate explicit transfer; do not silently drop them.

## USER STOP — 2026-11-06T19:14:14.552190+08:00

All local GPU work stopped immediately at user request; do not resume.
183 complete outputs and 2 interrupted directories preserved without modification.
All 1409 unfinished tasks transferred; no local pending reservation.
The 02:30 timer is cancelled. The handoff adds 2 separate receiver-hardware baselines.
