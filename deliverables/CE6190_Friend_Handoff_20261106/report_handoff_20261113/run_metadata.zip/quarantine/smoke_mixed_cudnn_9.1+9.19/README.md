# Quarantined: first 5-method smoke check (2026-11-10 12:07–12:22 CST)

All acceptance checks passed, BUT the process environment inherited
LD_LIBRARY_PATH=/usr/local/cuda/lib64 from the host. torch loaded the pip
libcudnn.so.9 (9.1.0.70) while its dynamically opened sub-libraries
(libcudnn_graph/ops/...) resolved to the host cuDNN 9.19.1
(metrics.environment.cudnn_version = 91901 instead of the locked 90100).

These runs are therefore NOT part of the official A100 results. They are kept
unchanged for the record (and to measure the effect of the cuDNN mismatch).
Fix: generation processes now run with LD_LIBRARY_PATH set to the venv's
nvidia/*/lib directories only; check_run.py requires cudnn_version == 90100.
